# Independent proportion audit

Audited saved laboratory_final.blend read-only in Blender 4.3.2 at 2026-10-17 12:31–12:32 UTC, before the metric-layout revision. No scene changes made. Detailed evaluated world-space bounds are in proportion_audit.json. Bounds include modifiers and hierarchy transforms. Rotated world AABBs are not manufacturer width/depth dimensions.

## Finding

The user's proportion concern is supported numerically. The official FR3 retains coherent source scale; oversized furniture and presentation-scaled props make it appear small. A 5.5 m foreground bench and 3.3 m hero bench substantially exceed the proposed compact photographic scene. Bottles and sample tubes also need correction, not just architecture.

## Measurements and revision targets (metres)

Targets below are illustrative estimates inferred from the photograph and a coherent compact laboratory layout, not surveyed dimensions or exact product CAD.

| Object | Audited current size | Proposed target | Base / top evidence |
|---|---|---|---|
| Room floor / ceiling | 7.00 × 6.70; ceiling underside 3.59 from source | 4.40 × 4.40 × 2.90 room | floor top 0.000 |
| Foreground bench | 5.50 × 1.35 × .90 | 2.80 × .85 × .90 | z 0.000–.900 |
| Hero bench | 3.30 × 1.25 × .95 | 2.00 × .80 × .95 | z 0.000–.950 |
| Rear counter | 5.80 × .80 × 1.00 | fit revised wall, about 3.4–3.8 × .60–.70 × .90–.95 | z 0.000–1.000 |
| BSC | local upper housing width 1.94, depth 1.16; tray 1.85 × 1.17 | overall about 1.35 × .80; worktop .90; top 2.20 | current tray .950–1.000; housing 1.945–2.350 |
| Centrifuge body | .671 × .548 × .382 | retain or modestly reduce width to .62 with uniform scale | base .950, body top 1.332 |
| Centrifuge including open lid | .673 × .707 × .858 | same device scale as body | base .950, top 1.808 |
| Official FR3 posed assembly | .689 × .288 × .992 world AABB | preserve official scale | base .950; top 1.942 |
| Held conical tube | .02196 × .02196 × .12740 | preserve current approximation | bottom 1.530, top 1.657 |
| Foreground bottles 0/1/2/3 | heights .468 / .393 / .355 / .318 | heights about .19–.24; normalize each individually | all bases .900 |
| Blue / white racks including tubes | about .313 × .183 × .282 | about .15–.16 × .085–.09 × .14 | base .900, top 1.182 |
| Rack tubes | rotated AABB about .063 diameter × .258 long | body diameter .017, cap .021, length .12–.129 | current bottom .924, top 1.182 |
| Chairs | about .76 footprint, top 1.26; seat top .72 | seat top .55–.62, back top 1.10–1.17; footprint .60–.70 | casters touch z0 |

Chairs' present high seat could be a deliberate high laboratory chair; changing it is a visual/layout choice rather than proof of an invalid real-world product. Width/depth of BSC world AABB is inflated by its 24° yaw; use local dimensions above when resizing. The aggregate 'BSC' JSON grouping includes chair/props and must not be interpreted as cabinet-only width/depth.

## Transform and source audit

- FR3 root and every URDF joint frame have world scale 1 within floating-point error. No inherited environment scaling reaches the robot.
- Official arm COLLADA files declare meter=1 and Z_UP, but their vertex coordinates are millimetre-sized and source visual-node matrices include .001 uniform scale. The importer applies those node matrices once. Hand and finger COLLADA node scales are 1 because their geometry is already metre-sized. Do not apply an additional .001 or scale the hand with arm geometry.
- Source matrices include real translations in the last column (e.g. link1 -.192 m, link3 -.121 m, link5 -.259 m, link6 -.0148 m, link7 +.052 m). The importer preserves these; source matrices have affine last rows and there is no evidence of a transpose/unit error.
- URDF frame increments are coherent: joint1 at base+.333, joint3 distance .316 from joint2, joint4 offset .0825, joint5 offset norm sqrt(.0825²+.384²), joint7 offset .088, flange .107. TCP is (.620,.680,1.650). Actual pose has .420m horizontal and .700m vertical base-to-TCP separation; changing its pose can alter apparent reach without changing mesh scale.
- Pinned source: https://github.com/frankarobotics/franka_description at 7aeeddc449edf8d62b594f9e36a81da53e7796f9. Independent SHA-256 recheck passed for all 33 manifest files. This audit inspected the source DAE metadata/matrices and evaluated joint and mesh transforms, but did not perform independent robot collision or engineering validation.
- Foreground reagent root scale is 1.65 and rack root scale 2.0. These presentation multipliers explain much of the mismatch. Centrifuge root already carries .78, giving a plausible current body size; avoid blindly shrinking it a second time.
- Removing rack presentation scaling alone does not fix tube diameter: lab_props.conical_tube uses base radius .0135 (27mm body) with a '15 mL' label. Set body radius around .0085 and cap radius around .0105 while retaining length; this aligns the rack tubes with the held-tube approximation.
- Existing BSC presentation adjustment scales only selected upper pieces vertically by .75 around z1 and separately shifts objects, leaving the horizontal size oversized. Rebuild as a coherent group or absolute dimensions instead of adding more accumulated transforms.
- Potential rebuild-only tube risk: replace_existing scales the held tube but does not set metric_tube_v1; refine_official_scene also scales it if that marker is absent. The audited saved tube has correct ~127mm length, so it is not double-scaled now, but mark scale application consistently or set absolute dimensions to avoid future cumulative reduction.

## Recommended order

1. Preserve FR3 mesh/node/joint scales and current .95m mounting height.
2. Set architecture and bench dimensions absolutely; reposition furniture coherently rather than scaling the whole scene.
3. Normalize props, tube diameter and chair height with bottom anchors maintained.
4. Keep centrifuge near its already plausible .67m width or set absolute .62m target.
5. Validate tabletop contacts and room fit in an orthographic overview before judging a perspective camera. Adjust camera only after the metric geometry is coherent.

## Additional measured props before revision

Exact evaluated mesh vertices (curves converted with to_mesh) give notebook .567 × .416 × .042m; gloves .349 × .361 × .123m; pipette stand .190 × .090 × .283m. Notebook and gloves retain presentation scales 1.5 and 2.0 respectively; pipette stand scale is1.0 and is already plausible. Headless evaluated curve bound_box can return a placeholder [-1,1]; converted vertices avoid this artifact. Post-revision targets: tabletop bottles .16–.22m high, tubes .017–.03m diameter/.10–.13m long, open notebook approximately .30–.45m wide, gloves .18–.30m footprint/.03–.08m high, pipettes .20–.30m length. These ranges are illustrative acceptance checks, not exact factory specifications.

## Corrected-native verification, 2026-10-17 12:39 UTC

PASS: corrected metric proportions and representative support heights. Measurements below are world axis-aligned dimensions, not local dimensions; yaw can increase width/depth. After measurements use actual evaluated mesh vertices, including converted curves. Before values generally use conservative transformed mesh-bound corners, except notebook/gloves/pipette use actual evaluated vertices.

| Object | Before W×D×H, m | After W×D×H, m | After bottom–top Z, m |
|---|---|---|---|
| Room | 7.000 × 6.700 × 0.180 | 4.400 × 4.400 × 0.180 | -0.180–0.000 |
| Foreground culture preparation bench | 5.500 × 1.350 × 0.900 | 2.800 × 0.850 × 0.900 | 0.000–0.900 |
| Robotic cell processing bench | 3.300 × 1.250 × 0.950 | 2.000 × 0.800 × 0.950 | 0.000–0.950 |
| Rear cleaning counter | 5.800 × 0.800 × 1.000 | 3.800 × 0.550 × 0.900 | 0.000–0.900 |
| Foreground reagent 0 | 0.177 × 0.132 × 0.468 | 0.081 × 0.061 × 0.215 | 0.900–1.115 |
| Foreground reagent 1 | 0.158 × 0.123 × 0.393 | 0.078 × 0.062 × 0.204 | 0.900–1.104 |
| Foreground reagent 2 | 0.145 × 0.115 × 0.355 | 0.074 × 0.060 × 0.193 | 0.900–1.093 |
| Foreground reagent 3 | 0.126 × 0.099 × 0.318 | 0.069 × 0.055 × 0.181 | 0.900–1.081 |
| Blue tube rack | 0.313 × 0.182 × 0.282 | 0.186 × 0.105 × 0.141 | 0.900–1.041 |
| White tube rack | 0.313 × 0.184 × 0.282 | 0.186 × 0.106 × 0.141 | 0.900–1.041 |
| Blue tube rack tube 0 0 | 0.063 × 0.063 × 0.258 | 0.019 × 0.019 × 0.129 | 0.912–1.041 |
| Held 15 mL conical tube | 0.022 × 0.022 × 0.127 | 0.022 × 0.022 × 0.127 | 1.530–1.657 |
| Open experiment notebook | 0.567 × 0.416 × 0.042 | 0.378 × 0.277 × 0.028 | 0.900–0.928 |
| Folded blue nitrile gloves | 0.349 × 0.361 × 0.123 | 0.175 × 0.180 × 0.061 | 0.900–0.961 |
| Pipette stand | 0.190 × 0.090 × 0.283 | 0.190 × 0.090 × 0.283 | 0.900–1.183 |
| BSC operator chair | 0.769 × 0.771 × 1.260 | 0.614 × 0.623 × 1.125 | 0.000–1.125 |
| Foreground technician chair | 0.757 × 0.743 × 1.260 | 0.625 × 0.613 × 1.125 | 0.000–1.125 |
| BSC sterile work tray | 2.166 × 1.821 × 0.050 | 1.350 × 0.800 × 0.050 | 0.850–0.900 |
| BSC upper filter plenum | 2.244 × 1.849 × 0.405 | 1.400 × 0.840 × 0.280 | 1.920–2.200 |

FR3 evaluated vertex extent is .675 × .253 × .992 m; its earlier conservative box-corner extent .689 × .288 × .992 m is a measurement-method difference, not rescaling. Joint scales remain 1 within 1.8e-07, base .950m, TCP (.620,.680,1.650) unchanged. Held tube .1274m remains correct. Source manifest independent SHA-256 recheck passed all33 files.

Ceiling underside is 2.920m (top3.040m), slightly different from rounded design target2.9m; no visual proportion blocker. Centrifuge open assembly .673 × .702 × .852m, base.950/top1.802m, still plausibly scaled. All foreground bottles, notebook, gloves, and BSC pipette stand have exact .900m bottoms; chair wheel bottoms0.000m and seat tops.610m. BSC tray top.900m/housing top2.200m. The tabletop tube height.129m and body/cap diameter are coherent with the held tube.

Final status: no remaining metric proportion blocker found. This is a visual proportion and support audit, not full collision, robot reach/safety, or engineering certification.
