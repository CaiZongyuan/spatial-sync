"""Run with blender -b laboratory_final.blend --python validate_scene.py."""
import bpy,json,os,math,hashlib
from mathutils import Vector
s=bpy.data.scenes.get('01 • Daylight laboratory');assert s is not None
assert bpy.data.scenes.get('02 • Night laboratory') is not None
assert s.camera is not None and s.camera.type=='CAMERA'
assert bpy.data.objects.get('FR3 • official robot master') is not None
assert bpy.data.objects.get('ROBOT • master') is None
assert bpy.data.objects.get('CENTRIFUGE • master') is not None
assert len(s.objects)>1000
missing=[im.filepath for im in bpy.data.images if im.source=='FILE' and not im.packed_file and not os.path.exists(bpy.path.abspath(im.filepath))];assert not missing,missing
bad=[o.name for o in s.objects if not all(math.isfinite(x) for row in o.matrix_world for x in row)];assert not bad,bad
supports={}
deps=bpy.context.evaluated_depsgraph_get()
for name in ['Foreground reagent 0','Foreground reagent 1','Foreground reagent 2','Foreground reagent 3','Culture dish stack','Petri dishes','Blue tube rack','White tube rack','Open experiment notebook','Folded blue nitrile gloves']:
 root=bpy.data.objects.get(name);assert root,name
 zs=[]
 for o in root.children_recursive:
  if o.type=='MESH':
   ev=o.evaluated_get(deps);zs.extend((ev.matrix_world@Vector(v)).z for v in ev.bound_box)
 minimum=min(zs);supports[name]={'bottom_z':round(minimum,5),'surface_z':.9,'gap_m':round(minimum-.9,5)}
 assert abs(minimum-.9)<.025,(name,minimum)
wheel_contacts={}
for o in s.objects:
 if ' caster' in o.name:
  z=min((o.matrix_world@Vector(v)).z for v in o.bound_box);wheel_contacts[o.name]=round(z,6);assert abs(z)<.002,(o.name,z)
official_root=bpy.data.objects['FR3 • official robot master']
assert all(abs(v-1)<1e-6 for v in official_root.scale)
official_meshes=[o for o in s.objects if o.type=='MESH' and o.get('official_source_mesh')]
assert len(official_meshes)==37,len(official_meshes)
joint_checks={}
for i in range(1,8):
 j=bpy.data.objects['fr3_joint'+str(i)];lo=j['limit_lower'];hi=j['limit_upper'];a=j.rotation_euler.z;assert lo-1e-6<=a<=hi+1e-6;joint_checks[j.name]={'angle':a,'lower':lo,'upper':hi}
for sc in bpy.data.scenes:
 assert not any(o.name.startswith('ROBOT • master') for o in sc.objects)
 assert sum(o.type=='MESH' and bool(o.get('official_source_mesh')) for o in sc.objects)==37
bpy.context.view_layer.update();tcp=bpy.data.objects['fr3_hand_tcp'].matrix_world.translation;target=Vector((.62,.68,1.65));assert (tcp-target).length<.0001,tuple(tcp)
assets=os.path.join(os.path.dirname(bpy.data.filepath),'official_fr3');provenance=json.load(open(os.path.join(assets,'asset_provenance.json')))
for f in provenance['files']:
 assert hashlib.sha256(open(os.path.join(assets,f['path']),'rb').read()).hexdigest()==f['sha256'],f['path']
for n in ['LICENSE','NOTICE','CONVERSION_NOTICE.txt']:
 assert bpy.data.texts['FR3 upstream '+n].as_string()==open(os.path.join(assets,n)).read(),n
report={'official_fr3':{'mesh_components':len(official_meshes),'metric_root_scale':list(official_root.scale),'joints':joint_checks,'tcp_world':list(tcp),'source_commit':provenance['commit'],'source_hashes_verified':len(provenance['files']),'embedded_license_texts_verified':True},'chair_wheel_floor_z':wheel_contacts,'passed':True,'scene_names':[sc.name for sc in bpy.data.scenes],'day_object_count':len(s.objects),'mesh_objects':sum(o.type=='MESH' for o in s.objects),'material_count':len(bpy.data.materials),'missing_external_images':missing,'finite_transforms':not bad,'unit_system':s.unit_settings.system,'support_checks':supports,'resolution':[s.render.resolution_x,s.render.resolution_y], 'samples':s.cycles.samples,'limits':['Metric dimensions inferred from one photograph; no engineering accuracy claimed.','Support checks validate representative tabletop props, not every deliberate assembly intersection.','Organic glove and plant shapes are procedural approximations.','Lighting uses analytic sun/area sources, no measured IES.']}
path=os.path.join(os.path.dirname(bpy.data.filepath),'scene_validation.json')
with open(path,'w') as f:json.dump(report,f,indent=2)
print('VALIDATION_PASS',json.dumps(report))
