"""Idempotent, geometry-only visual polish for an already assembled laboratory."""
import bpy
from mathutils import Vector

def polish_heroes():
    scene=bpy.context.scene
    if scene.get('hero_polish_v1'):return
    # Official FR3 geometry is never resized or altered. Polish centrifuge only.
    old=bpy.data.materials.get('Hero • graphite elastomer')
    if old and old.use_nodes:
        p=old.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.012,.017,.020,1);p.inputs['Roughness'].default_value=.45
    disc=next((o for o in bpy.data.objects if o.name.startswith('Lid inner circular brushed plate')),None)
    if disc:
        m=bpy.data.materials.get('Hero • lid warm grey inset') or bpy.data.materials.new('Hero • lid warm grey inset');m.use_nodes=True
        p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.20,.205,.18,1);p.inputs['Metallic'].default_value=.38;p.inputs['Roughness'].default_value=.43
        disc.data.materials.clear();disc.data.materials.append(m)
        ringmat=bpy.data.materials.get('Hero • lid recessed ring') or bpy.data.materials.new('Hero • lid recessed ring');ringmat.use_nodes=True
        p=ringmat.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.10,.115,.10,1);p.inputs['Metallic'].default_value=.45;p.inputs['Roughness'].default_value=.39
        bpy.context.view_layer.update()
        for i,r in enumerate([.222,.245]):
            bpy.ops.mesh.primitive_torus_add(major_segments=80,minor_segments=8,major_radius=r,minor_radius=.0025)
            ring=bpy.context.object;ring.name='Lid inset concentric channel %02d'%i
            for c in list(ring.users_collection):c.objects.unlink(ring)
            disc.users_collection[0].objects.link(ring)
            ring.parent=disc;ring.location=(0,0,-.010);ring.rotation_euler=(0,0,0);ring.data.materials.append(ringmat)
            for f in ring.data.polygons:f.use_smooth=True
    scene['hero_polish_v1']=True
    bpy.context.view_layer.update()
