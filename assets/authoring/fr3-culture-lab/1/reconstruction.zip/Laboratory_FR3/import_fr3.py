"""Official Franka Research 3 (fr3/Arm3R) mesh importer, Blender 4.3.
Own conversion code; upstream meshes and robot parameters unchanged.
Call replace_existing() after procedural hero creation, or build_robot() alone.
Joint controls rotate local Z; URDF origin frames are separate immutable parents.
"""
import bpy, json, math
from pathlib import Path
from mathutils import Matrix,Vector,Euler
ROOT=Path(__file__).resolve().parent
ASSETS=ROOT/'official_fr3'
POSE=json.loads((ASSETS/'pose.json').read_text())
COL=None

def empty(name,parent=None,xyz=(0,0,0),rpy=(0,0,0)):
 o=bpy.data.objects.new(name,None);COL.objects.link(o);o.parent=parent;o.location=xyz;o.rotation_euler=rpy;o.empty_display_size=.045;return o

def import_visual(path,parent,name):
 """Read this upstream COLLADA subset explicitly; preserve geometry, normals, materials, node matrices."""
 import xml.etree.ElementTree as ET
 r=ET.parse(path).getroot();ns={'c':'http://www.collada.org/2005/11/COLLADASchema'}
 assert r.find('c:asset/c:up_axis',ns).text=='Z_UP'
 assert float(r.find('c:asset/c:unit',ns).get('meter'))==1.
 ids={x.get('id'):x for x in r.iter() if x.get('id')};materials={};added=[]
 for m in r.findall('c:library_materials/c:material',ns):
  effect=ids[m.find('c:instance_effect',ns).get('url')[1:]];col=effect.find('.//c:diffuse/c:color',ns);rgba=[float(x) for x in col.text.split()] if col is not None else [.8,.8,.8,1]
  mat=bpy.data.materials.new('FR3 source • '+m.get('name',m.get('id')));mat.diffuse_color=rgba;mat.use_nodes=True;p=mat.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=rgba;p.inputs['Roughness'].default_value=.32
  materials[m.get('id')]=mat
 def walk(node,transform):
  transform=transform.copy()
  for t in node:
   tag=t.tag.split('}')[-1]
   if tag=='matrix':
    a=list(map(float,t.text.split()));transform=transform@Matrix([a[i:i+4] for i in range(0,16,4)])
   elif tag in ('translate','rotate','scale'):raise ValueError('Unexpected transform: '+tag)
  for inst in node.findall('c:instance_geometry',ns):
   geo=ids[inst.get('url')[1:]];mesh=geo.find('c:mesh',ns);sources={}
   for s in mesh.findall('c:source',ns):
    a=list(map(float,s.find('c:float_array',ns).text.split()));stride=int(s.find('c:technique_common/c:accessor',ns).get('stride'));sources[s.get('id')]=[a[i:i+stride] for i in range(0,len(a),stride)]
   vertices={v.get('id'):v.find('c:input[@semantic="POSITION"]',ns).get('source')[1:] for v in mesh.findall('c:vertices',ns)}
   faces=[];normals=[];face_mats=[];positions=None
   bindings={v.get('symbol'):v.get('target')[1:] for v in inst.findall('.//c:instance_material',ns)}
   mats=[]
   for tri in mesh.findall('c:triangles',ns):
    inputs=tri.findall('c:input',ns);stride=max(int(x.get('offset')) for x in inputs)+1;vi=next(x for x in inputs if x.get('semantic')=='VERTEX');ni=next((x for x in inputs if x.get('semantic')=='NORMAL'),None)
    pos=sources[vertices[vi.get('source')[1:]]]
    if positions is None:positions=pos
    assert positions==pos
    p=list(map(int,tri.find('c:p',ns).text.split()));vo=int(vi.get('offset'));idx=[p[i+vo] for i in range(0,len(p),stride)];faces.extend([idx[i:i+3] for i in range(0,len(idx),3)])
    if ni is not None:
     no=int(ni.get('offset'));normals.extend(sources[ni.get('source')[1:]][p[i+no]] for i in range(0,len(p),stride))
    mid=bindings[tri.get('material')]
    if mid not in mats:mats.append(mid)
    face_mats.extend([mats.index(mid)]*(len(idx)//3))
   me=bpy.data.meshes.new(name+' • '+geo.get('id'));me.from_pydata(positions,[],faces);me.update()
   for mid in mats:me.materials.append(materials[mid])
   for poly,mi in zip(me.polygons,face_mats):poly.material_index=mi;poly.use_smooth=True
   if len(normals)==len(me.loops):me.normals_split_custom_set(normals)
   o=bpy.data.objects.new(name+' • '+node.get('name','mesh'),me);COL.objects.link(o);o.parent=parent;o.matrix_basis=transform;o['official_source_mesh']=str(path.relative_to(ASSETS));o['units']='metres; upstream meter=1; DAE node matrix preserved';added.append(o)
  for child in node.findall('c:node',ns):walk(child,transform)
 for node in r.findall('c:library_visual_scenes/c:visual_scene/c:node',ns):walk(node,Matrix.Identity(4))
 return added

def build_robot(location=None):
 global COL
 COL=bpy.data.collections.new('OFFICIAL FR3 • licensed source meshes');bpy.context.scene.collection.children.link(COL)
 root=empty('FR3 • official robot master',xyz=location or POSE['base']);root['manufacturer']='Franka Robotics GmbH';root['model']='Franka Research 3 / fr3 / Arm3R';root['source']='https://github.com/frankarobotics/franka_description';root['source_commit']=(ASSETS/'COMMIT').read_text().strip();root['license']='Apache-2.0; see embedded upstream LICENSE and NOTICE';root['geometry_scale']='1:1 metres; no stretched links';root['simulation_note']='Visual articulated model; not safety-validated robotics control or collision simulation.'
 link0=empty('fr3_link0',root);import_visual(ASSETS/'meshes/robots/fr3/visual/link0.dae',link0,'FR3 official link0');prev=link0
 for i,j in enumerate(POSE['joints'],1):
  k=j['origin'];origin=empty(f'fr3_joint{i} • URDF origin',prev,tuple(k[x] for x in ['x','y','z']),tuple(k[x] for x in ['roll','pitch','yaw']))
  joint=empty(f'fr3_joint{i}',origin);joint['joint_type']='revolute' if i<8 else 'fixed';joint['axis']=[0.,0.,1.]
  if i<8:
   joint.rotation_euler.z=POSE['joint_angles'][i-1]
   for key,value in j['limit'].items():joint['limit_'+key]=value
   con=joint.constraints.new('LIMIT_ROTATION');con.owner_space='LOCAL';con.use_limit_x=True;con.use_limit_y=True;con.use_limit_z=True;con.min_z=j['limit']['lower'];con.max_z=j['limit']['upper']
  link=empty(f'fr3_link{i}',joint)
  if i<8:import_visual(ASSETS/f'meshes/robots/fr3/visual/link{i}.dae',link,f'FR3 official link{i}')
  prev=link
 hand=empty('fr3_hand',prev,rpy=(0,0,-math.pi/4));import_visual(ASSETS/'meshes/robot_ee/franka_hand_white/visual/hand.dae',hand,'FR3 official white hand')
 for side,yaw in [('left',0),('right',math.pi)]:
  origin=empty(f'fr3_{side}finger • URDF origin',hand,(0,0,.0584),(0,0,yaw));slider=empty(f'fr3_{side}finger_joint',origin,(0,.0105,0));slider['joint_type']='prismatic';slider['axis']=[0.,1.,0.];slider['limit_lower']=0.;slider['limit_upper']=.04
  con=slider.constraints.new('LIMIT_LOCATION');con.owner_space='LOCAL';con.use_min_y=True;con.use_max_y=True;con.min_y=0;con.max_y=.04
  if side=='right':
   curve=slider.driver_add('location',1);v=curve.driver.variables.new();v.name='opening';v.targets[0].id=bpy.data.objects['fr3_leftfinger_joint'];v.targets[0].data_path='location[1]';curve.driver.expression='opening'
  import_visual(ASSETS/'meshes/robot_ee/franka_hand_white/visual/finger.dae',slider,f'FR3 official {side} finger')
 tcp=empty('fr3_hand_tcp',hand,(0,0,.1034));tcp['description']='Official hand TCP; held tube is a separate scene prop'
 for fname in ['LICENSE','NOTICE','CONVERSION_NOTICE.txt']:
  text=bpy.data.texts.get('FR3 upstream '+fname) or bpy.data.texts.new('FR3 upstream '+fname);text.clear();text.write((ASSETS/fname).read_text())
 bpy.context.view_layer.update();return root

def replace_existing(location=None):
 old=bpy.data.objects.get('ROBOT • master');tube=bpy.data.objects.get('Held 15 mL conical tube')
 if tube:
  bpy.context.view_layer.update();w=tube.matrix_world.copy();tube.parent=None;tube.matrix_world=w
 if old:
  for o in list(old.children_recursive)+[old]:bpy.data.objects.remove(o,do_unlink=True)
 root=build_robot(location)
 if tube:
  tcp=bpy.data.objects['fr3_hand_tcp'];bpy.context.view_layer.update();w=tube.matrix_world.copy();w=w@Matrix.Diagonal((.36,.36,.57,1.));w.translation=tcp.matrix_world.translation+Vector((0,0,-.0456));tube.matrix_world=w;tube.parent=tcp;tube.matrix_world=w;tube['attachment']='Separate approximate 15mL prop; cap held at official fr3_hand_tcp; not upstream robot';tube['approx_dimensions']='body diameter 17.28 mm, cap diameter 20.88 mm, overall length about 127 mm; illustration dimensions, not clinical specification'
 bpy.context.view_layer.update()
 return root
