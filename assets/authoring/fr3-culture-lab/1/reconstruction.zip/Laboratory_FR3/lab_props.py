"""Detailed procedural lab dressing for Blender 4.3, meters, Z-up.
All assets modeled from primitives/curves/meshes; no generated AI assets.
Public builders return bottom-anchored Empty hierarchies. build(ctx) is scene entry.
"""
import bpy, math, random
from mathutils import Vector
RNG=random.Random(197)
COL=None

def material(name,color,rough=.4,metal=0,trans=0,ior=1.46):
    name='Props | '+name
    if name in bpy.data.materials:return bpy.data.materials[name]
    m=bpy.data.materials.new(name);m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1)
    p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
    p.inputs['Transmission Weight'].default_value=trans;p.inputs['IOR'].default_value=ior
    return m

def palette():
    return dict(glass=material('clear borosilicate',(.91,.97,1),.085,trans=.97),pink=material('rose cell medium',(.64,.035,.075),.19,trans=.65,ior=1.334),blue=material('cobalt caps',(.025,.14,.38),.31),white=material('warm white polymer',(.83,.85,.82),.38),orange=material('orange caps',(.85,.18,.035),.3),paper=material('off white labels',(.88,.87,.79),.75),ink=material('charcoal printing',(.025,.04,.045),.7),steel=material('brushed stainless',(.45,.51,.53),.27,.83),glove=material('blue nitrile',(.075,.24,.47),.7),leaf=material('pothos green',(.15,.25,.047),.46),leaflight=material('pothos golden variegation',(.37,.42,.10),.52),stem=material('green stems',(.13,.19,.045),.65),pot=material('cream ceramic pot',(.63,.60,.49),.35),soil=material('pot soil',(.045,.03,.018),.97),black=material('rubber cables',(.018,.025,.026),.7))
M=None

def setup():
    global COL,M
    if M is None:M=palette()
    if COL is None:
        COL=bpy.data.collections.get('Lab | Detailed small props')
        if COL is None:COL=bpy.data.collections.new('Lab | Detailed small props');bpy.context.scene.collection.children.link(COL)

def own(o,parent=None,mat=None):
    for c in list(o.users_collection):c.objects.unlink(o)
    COL.objects.link(o)
    if parent:o.parent=parent
    if mat:o.data.materials.append(mat)
    return o

def root(name):
    setup();o=bpy.data.objects.new(name,None);COL.objects.link(o);o.empty_display_size=.07;return o

def mesh(name,verts,faces,mat,parent):
    d=bpy.data.meshes.new(name);d.from_pydata(verts,[],faces);d.update();o=bpy.data.objects.new(name,d);COL.objects.link(o);o.parent=parent;d.materials.append(mat)
    return o

def box(name,loc,dims,mat,parent,bevel=.003):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=own(bpy.context.object,parent,mat);o.name=name;o.scale=dims
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    if bevel:
        b=o.modifiers.new('Manufactured softened edges','BEVEL');b.width=bevel;b.segments=3
        o.modifiers.new('Weighted surface normals','WEIGHTED_NORMAL')
    return o

def cylinder(name,loc,radius,depth,mat,parent,vertices=32):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=loc);o=own(bpy.context.object,parent,mat);o.name=name
    b=o.modifiers.new('Fine rim bevel','BEVEL');b.width=min(.0015,radius*.08,depth*.12);b.segments=2
    for p in o.data.polygons:p.use_smooth= len(p.vertices)==4
    o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');return o

def curve(name,points,radius,mat,parent):
    d=bpy.data.curves.new(name,'CURVE');d.dimensions='3D';d.resolution_u=12;d.bevel_depth=radius;d.bevel_resolution=3
    s=d.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
    for p,v in zip(s.bezier_points,points):p.co=v;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
    o=bpy.data.objects.new(name,d);COL.objects.link(o);o.parent=parent;d.materials.append(mat);return o

def lettering(name,body,loc,size,parent,mat=None,rot=(math.pi/2,0,0)):
    d=bpy.data.curves.new(name,'FONT');d.body=body;d.size=size;d.extrude=.00003;d.space_character=1.1
    o=bpy.data.objects.new(name,d);COL.objects.link(o);o.parent=parent;o.location=loc;o.rotation_euler=rot;d.materials.append(mat or M['ink']);return o

def rings(name,profiles,mat,parent,n=40,square=False):
    verts=[]
    for z,rx,ry in profiles:
        for j in range(n):
            a=j*2*math.pi/n;c,s=math.cos(a),math.sin(a)
            if square:c=math.copysign(abs(c)**.45,c);s=math.copysign(abs(s)**.45,s)
            verts.append((rx*c,ry*s,z))
    faces=[tuple(range(n-1,-1,-1))]
    for k in range(len(profiles)-1):
        for j in range(n):faces.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
    faces.append(tuple((len(profiles)-1)*n+j for j in range(n)))
    o=mesh(name,verts,faces,mat,parent)
    for p in o.data.polygons:p.use_smooth=len(p.vertices)==4
    return o

def finish(parent,pos,angle=0):
    """Move evaluated hierarchy minimum Z exactly to target support surface."""
    bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get();zs=[]
    for o in parent.children_recursive:
        if o.type in {'MESH','CURVE','FONT'}:
            ev=o.evaluated_get(deps)
            
            if o.type=='MESH':
                zs.extend((ev.matrix_world@Vector(v)).z for v in ev.bound_box)
            elif o.type=='CURVE':
                evaluated_mesh=ev.to_mesh()
                zs.extend((ev.matrix_world@v.co).z for v in evaluated_mesh.vertices)
                ev.to_mesh_clear()
    if zs:
        # Children are authored local to an identity parent.
        for o in parent.children:o.location.z-=min(zs)
    parent.location=pos;parent.rotation_euler.z=angle
    parent['support_z']=pos[2];parent['asset_origin']='Procedural geometry, photograph guided'
    return parent

def culture_bottle(name='Culture medium bottle',pos=(0,0,0),label='DMEM',cap='white',fill=.56,scale=1,angle=0):
    p=root(name);w,d,h=.085*scale,.062*scale,.22*scale
    # Thin closed shell follows rounded rectangular body through tapered shoulder.
    prof=[(0,w*.43,d*.43),(.006*scale,w/2,d/2),(h*.72,w/2,d/2),(h*.85,.018*scale,.018*scale),(h*.95,.018*scale,.018*scale),(h*.95,.0165*scale,.0165*scale),(h*.85,.0165*scale,.0165*scale),(h*.715,w/2-.0015,d/2-.0015),(.002,w/2-.002,d/2-.002)]
    rings(name+' clear hollow vessel',prof,M['glass'],p,square=True)
    rings(name+' pink medium',[(.004,w*.47,d*.47),(h*fill,w*.47,d*.47)],M['pink'],p,square=True)
    cylinder('Screw cap',(0,0,h*.976),.020*scale,.024*scale,M[cap],p)
    for j in range(16):
        a=j*math.tau/16
        box('Cap grip rib',(.020*scale*math.cos(a),.020*scale*math.sin(a),h*.976),(.0013*scale,.0013*scale,.018*scale),M[cap],p,.0004)
    box('Bottle adhesive label',(0,-d/2-.0008,h*.42),(w*.78,.001,h*.35),M['paper'],p,.001)
    lettering('Medium name',label,(-w*.34,-d/2-.0015,h*.49),.012*scale,p)
    lettering('Medium label details','CELL CULTURE\n500 mL   STERILE\nLOT 24A018',(-w*.34,-d/2-.0016,h*.415),.0047*scale,p)
    for i in range(6):box('Volume graduation',(w*.38,-d/2-.001,h*(.2+i*.075)),(.010*scale,.0007,.0008),M['white'],p,0)
    return finish(p,pos,angle)

def conical_tube(name='Conical tube',pos=(0,0,0),cap='orange',scale=1,fill=.35,angle=0):
    p=root(name);r=.0085*scale;h=.115*scale
    rings('Transparent graduated tube',[(0,.001,.001),(.025*scale,r,r),(h,r,r),(h,r-.0007,r-.0007),(.025*scale,r-.0007,r-.0007),(.003,.001,.001)],M['glass'],p,n=24)
    rings('Tube liquid',[(.002,.001,.001),(.025*scale,r-.001,r-.001),(max(.026,h*fill),r-.001,r-.001)],M['pink'],p,n=24)
    cylinder('Tube screw cap',(0,0,h+.007*scale),r*1.12,.014*scale,M[cap],p,24)
    for i in range(7):box('Tube measure tick',(-.004,-r-.0003,(.035+i*.009)*scale),(.005,.0004,.0006),M['ink'],p,0)
    lettering('Tube sterile text','15 mL',(-.009,-r-.0006,.095*scale),.004*scale,p)
    return finish(p,pos,angle)

def tube_rack(name='Tube rack',pos=(0,0,0),color='blue',rows=2,cols=4,angle=0):
    p=root(name);pitch=.028;w=(cols+0.5)*pitch;d=(rows+.5)*pitch
    box('Rack bottom',(0,0,.006),(w,d,.012),M[color],p)
    for x in [-w/2+.006,w/2-.006]:
        for y in [-d/2+.006,d/2-.006]:box('Rack upright',(x,y,.032),(.009,.009,.064),M[color],p,.002)
    for z in [.030,.065]:
        for j in range(rows+1):box('Rack long lattice',(0,(j-rows/2)*pitch,z),(w,.007,.007),M[color],p,.001)
        for i in range(cols+1):box('Rack cross lattice',((i-cols/2)*pitch,0,z),(.007,d,.007),M[color],p,.001)
    for i in range(cols):
        for j in range(rows):
            t=conical_tube(name+' tube %s %s'%(i,j),((i-(cols-1)/2)*pitch,(j-(rows-1)/2)*pitch,.012),cap=('orange' if color=='white' else 'blue'),fill=RNG.uniform(.26,.56));t.parent=p
    return finish(p,pos,angle)

def culture_dish_stack(name='Culture dish stack',pos=(0,0,0),count=4,angle=0):
    p=root(name)
    for i in range(count):
        z=i*.022
        box('Dish clear base',(0,0,z+.002),(.23,.16,.004),M['glass'],p,.003)
        box('Thin medium layer',(0,0,z+.006),(.218,.148,.005),M['pink'],p,.003)
        for x in [-.113,.113]:box('Dish sidewall',(x,0,z+.011),(.004,.16,.018),M['glass'],p,.0015)
        for y in [-.078,.078]:box('Dish endwall',(0,y,z+.011),(.222,.004,.018),M['glass'],p,.0015)
        box('Clear lid',(0,0,z+.020),(.235,.165,.003),M['glass'],p,.003)
    return finish(p,pos,angle)

def petri_stack(name='Petri dishes',pos=(0,0,0),count=3):
    p=root(name)
    for i in range(count):
        z=i*.015
        rings('Petri glass wall',[(z,.045,.045),(z+.012,.045,.045),(z+.012,.0435,.0435),(z+.001,.0435,.0435)],M['glass'],p)
        cylinder('Petri agar medium',(0,0,z+.003),.042,.003,M['pink'],p)
        cylinder('Petri transparent lid',(0,0,z+.014),.046,.002,M['glass'],p)
    return finish(p,pos)

def pipette_stand(name='Pipette stand',pos=(0,0,0),angle=0):
    p=root(name);box('Pipette stand foot',(0,0,.007),(.19,.09,.014),M['white'],p,.006)
    box('Stand back',(0,.026,.13),(.018,.017,.25),M['white'],p,.004)
    box('Stand rack beam',(0,0,.24),(.19,.045,.016),M['white'],p,.005)
    for i in range(4):
        x=(i-1.5)*.044
        cylinder('Pipette handle',(x,-.026,.185),.011,.12,M['white'],p)
        cylinder('Pipette grip collar',(x,-.026,.232),.014,.025,M['blue'],p)
        cylinder('Pipette plunger stem',(x,-.026,.261),.003,.031,M['steel'],p)
        cylinder('Pipette thumb button',(x,-.026,.28),.009,.006,M['blue'],p)
        rings('Pipette tapered shaft',[(.055,.0018,.0018),(.12,.005,.005),(.13,.008,.008)],M['white'],p,n=16).location=(x,-.026,0)
        box('Pipette digital volume window',(x,-.037,.195),(.011,.001,.023),M['ink'],p,.002)
        lettering('Pipette volume','100', (x-.0045,-.038,.194),.004,p,M['paper'])
    return finish(p,pos,angle)

def notebook(name='Open experiment notebook',pos=(0,0,0),angle=0):
    p=root(name);box('Notebook black cover',(0,0,.004),(.36,.25,.008),M['black'],p,.004)
    for x in [-.087,.087]:
        box('Cream paper block',(x,0,.012),(.169,.241,.012),M['paper'],p,.002)
        for j in range(13):box('Ruled paper line',(x,-.096+j*.015,.0185),(.148,.00035,.0001),M['blue'],p,0)
    for j in range(11):
        y=-.10+j*.019
        curve('Notebook binding', [(-.006,y,.018),(0,y,.024),(.006,y,.018)],.001,M['steel'],p)
    lettering('Notebook heading','CULTURE LOG',(-.16,.077,.019),.009,p,rot=(0,0,0))
    lettering('Notebook notes','17 OCT   /   passage 04\nDMEM + 10% FBS\n37 C    5% CO2',(.017,.052,.019),.006,p,rot=(0,0,0))
    curve('Black ballpoint pen',[(-.14,-.09,.025),(-.012,-.071,.025)],.0035,M['ink'],p)
    curve('Metal pen tip',[(-.012,-.071,.025),(.005,-.069,.025)],.0017,M['steel'],p)
    return finish(p,pos,angle)

def tapered_soft_tube(name,points,radii,parent,mat,n=12):
    vs=[]
    for k,c in enumerate(points):
        for j in range(n):
            a=j*math.tau/n;vs.append((c[0]+math.cos(a)*radii[k],c[1],c[2]+math.sin(a)*radii[k]*.55))
    fs=[tuple(range(n-1,-1,-1))]
    for k in range(len(points)-1):
        for j in range(n):fs.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
    fs.append(tuple((len(points)-1)*n+j for j in range(n)))
    o=mesh(name,vs,fs,mat,parent)
    sub=o.modifiers.new('Soft nitrile folds','SUBSURF');sub.levels=2
    for f in o.data.polygons:f.use_smooth=True
    return o

def folded_gloves(name='Folded blue nitrile gloves',pos=(0,0,0),angle=0):
    p=root(name)
    for g in range(2):
        off=g*.033;z=g*.013
        tapered_soft_tube('Soft folded glove palm',[(off,-.03,z+.014),(off,.0,z+.024),(off+.006,.035,z+.018),(off+.007,.07,z+.012)],[.034,.045,.043,.031],p,M['glove'])
        for i in range(4):
            x=off+(i-1.5)*.020;ln=[.065,.082,.076,.057][i]
            tapered_soft_tube('Curled tapered finger',[(x,.038,z+.018),(x+.006,.068,z+.016),(x+.012,.068+ln*.5,z+.009),(x+.016,.064+ln,z+.012)],[.012,.011,.008,.0015],p,M['glove'])
        tapered_soft_tube('Bent thumb',[(off-.026,.013,z+.02),(off-.051,.04,z+.018),(off-.060,.066,z+.008),(off-.047,.081,z+.009)],[.015,.013,.009,.002],p,M['glove'])
        curve('Folded cuff hem',[(off-.032,-.029,z+.016),(off,-.037,z+.022),(off+.031,-.028,z+.015)],.003,M['glove'],p)
    return finish(p,pos,angle)

def leaf(name,center,size,angle,parent,light=False):
    # Cupped pointed heart/ovate leaf with central raised rib.
    x,y,z=center;vs=[(0,0,.006),(-.45*size,-.12*size,0),(-.51*size,.28*size,.002),(-.22*size,.67*size,0),(0,size,-.008),(.22*size,.67*size,0),(.51*size,.28*size,.002),(.45*size,-.12*size,0)]
    o=mesh(name,vs,[(0,j,j+1) for j in range(1,7)]+[(0,7,1)],M['leaflight' if light else 'leaf'],parent);o.location=center;o.rotation_euler=(.4,-.25,angle)
    sub=o.modifiers.new('Leaf silhouette smoothing','SUBSURF');sub.levels=2
    sol=o.modifiers.new('Leaf thickness','SOLIDIFY');sol.thickness=.0005
    return o

def trailing_plant(name='Trailing pothos plant',pos=(0,0,0),angle=0):
    p=root(name)
    rings('Ceramic pot',[(0,.065,.065),(.12,.085,.085),(.13,.085,.085),(.13,.078,.078),(.012,.060,.060)],M['pot'],p)
    cylinder('Dark potting soil',(0,0,.119),.076,.005,M['soil'],p)
    for k in range(5):
        a=k*math.tau/5;pts=[]
        for j in range(8):
            t=j/7;rad=.02+.15*t;z=.13+.12*math.sin(t*math.pi)-(.42 if k<3 else .12)*t*t
            pts.append((rad*math.cos(a)+.018*math.sin(j),rad*math.sin(a)-.11*t,z))
        curve('Trailing pothos vine',pts,.002,M['stem'],p)
        for j in range(1,8):
            c=pts[j];leaf('Golden pothos leaf',c,.054+RNG.random()*.023,a+(-1 if j%2 else 1)*.9,p,j%4==0)
    # Plant origin is deliberately pot bottom, with hanging leaves below shelf.
    p.location=pos;p.rotation_euler.z=angle;p['support_z']=pos[2];p['hanging_asset']=True;return p

def cable(name='Instrument power cable',pos=(0,0,0),points=None):
    p=root(name);curve('Soft rubber cable',points or [(0,0,.004),(.12,.03,.004),(.22,.01,.004),(.27,.12,.004)],.003,M['black'],p);return finish(p,pos)

def build_lab_props(config=None):
    cfg=config or {};z=cfg.get('front_top',.9);assets=[]
    for i,(x,y,lab,cap,s) in enumerate([(-1.1,-.9,'DMEM','white',.95),(-.95,-.58,'DMEM','white',.90),(-1.25,-.62,'PBS','blue',.85),(-1.1,-1.05,'TrypLE','white',.80)]):
        assets.append(culture_bottle('Foreground reagent '+str(i),(x,y,z),lab,cap,scale=s,angle=RNG.uniform(-.14,.14)))
    assets.append(culture_dish_stack(pos=(-.55,-.72,z),angle=.07))
    assets.append(petri_stack(pos=(-.28,-.55,z)))
    assets.append(tube_rack('Blue tube rack',(.35,-.62,z),'blue',cols=6,rows=3,angle=-.04))
    assets.append(tube_rack('White tube rack',(.65,-.65,z),'white',cols=6,rows=3,angle=.045))
    assets.append(notebook(pos=(-.05,-.95,z),angle=-.08))
    assets.append(folded_gloves(pos=(-.55,-1.0,z),angle=-.55))
    assets.append(pipette_stand(pos=(-1.30,.98,.9)))
    for i in range(3):assets.append(culture_bottle('BSC culture reagent '+str(i),(-1.90+i*.15,.78,.9),['DMEM','PBS','FBS'][i],['orange','white','blue'][i],scale=.9))
    assets.append(tube_rack('BSC sterile tube rack',(-.92,.70,.9),'white',cols=3))
    assets.append(culture_dish_stack('BSC culture dishes',(-1.26,.61,.9),2))
    assets.append(tube_rack('Hero bench sample rack',(0,.35,.95),'white',cols=3))
    assets.append(cable(pos=(-.3,.65,.95),points=[(0,0,.004),(-.08,-.12,.004),(-.12,-.16,.004),(-.15,-.10,.004)]))
    if 'plant_pos' in cfg:assets.append(trailing_plant(pos=cfg['plant_pos']))
    for item in cfg.get('shelf_bottles',[]):assets.append(culture_bottle(pos=item,label='DMEM',cap='blue'))
    return assets

def build(ctx=None):
    ctx=ctx or {};return build_lab_props(ctx.get('props_config',{}))

if __name__=='__main__':
    build_lab_props({'plant_pos':(2,2,1.7)})
    bpy.context.view_layer.update()
    print('LAB_PROPS_OK',len(COL.objects),'objects')
