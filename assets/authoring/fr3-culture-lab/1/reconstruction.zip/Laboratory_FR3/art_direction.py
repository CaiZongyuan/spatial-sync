"""Metric scene finish. Official FR3 geometry is never rescaled."""
import bpy,math
from mathutils import Vector

def apply(scene):
 c=scene.camera;c.location=(1.1,-3.5,2.15);c.rotation_euler=(Vector((-.1,.9,1.25))-c.location).to_track_quat('-Z','Y').to_euler();c.data.lens=46;c.data.dof.aperture_fstop=9;c.data.dof.focus_distance=(c.location-Vector((.3,.7,1.45))).length
 chair=bpy.data.objects.get('Foreground technician chair')
 if chair:chair.location.y=-1.05
 cf=bpy.data.objects.get('CENTRIFUGE • master')
 if cf:cf.scale=(.78,.78,.78);cf.location=(1,.7,.95)
 for o in scene.objects:
  if o.name.startswith('Venetian blind'):o.rotation_euler.x=math.radians(12)
  if o.type=='LIGHT':
   if o.name.startswith('DAY late'):o.data.energy=7;o.data.color=(1,.73,.43);o.data.angle=math.radians(.7);o.rotation_euler=Vector((-.35,-1,-.45)).to_track_quat('-Z','Y').to_euler()
   if o.name.startswith('DAY broad'):o.data.energy=70
   if o.name.startswith('DAY soft'):o.data.energy=110;o.data.color=(1,.82,.62)
 mat=bpy.data.materials.get('Brushed stainless steel')
 if mat:mat.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.4
 if not bpy.data.objects.get('Warm exterior sky backing'):
  m=bpy.data.materials.new('Warm luminous exterior sky');m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.84,.85,.83,1);p.inputs['Emission Color'].default_value=(1,.91,.72,1);p.inputs['Emission Strength'].default_value=.8
  bpy.ops.mesh.primitive_cube_add(size=1,location=(0,15,6));o=bpy.context.object;o.name='Warm exterior sky backing';o.dimensions=(35,.1,16);o.data.materials.append(m);o.visible_shadow=False
 for material_name in ['Props | clear borosilicate','Hero • clear tube polypropylene']:
  m=bpy.data.materials.get(material_name)
  if m and not m.get('thin_labware_mix'):
   ns=m.node_tree.nodes;p=ns.get('Principled BSDF');out=ns.get('Material Output');transparent=ns.new('ShaderNodeBsdfTransparent');mix=ns.new('ShaderNodeMixShader');mix.inputs[0].default_value=.58;m.node_tree.links.new(p.outputs['BSDF'],mix.inputs[1]);m.node_tree.links.new(transparent.outputs[0],mix.inputs[2]);m.node_tree.links.new(mix.outputs[0],out.inputs['Surface']);m['thin_labware_mix']=True
 for material_name in ['Props | rose cell medium','Hero • pink culture medium']:
  m=bpy.data.materials.get(material_name)
  if m:
   p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.8,.12,.18,1);p.inputs['Transmission Weight'].default_value=.35;p.inputs['Roughness'].default_value=.16
 for s in bpy.data.scenes:s.cycles.max_bounces=12;s.cycles.transmission_bounces=10;s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.03;s.cycles.adaptive_min_samples=32
 m=bpy.data.materials.get('Subtle airborne dust volume')
 if m:m.node_tree.nodes.get('Principled Volume').inputs['Density'].default_value=.0005
 for o in scene.objects:
  if o.name.startswith('Atmospheric interior volume'):o.display_type='WIRE'
  if ' caster' in o.name and o.parent:o.location.z=.04
  o.select_set(False)
 root=bpy.data.objects.get('FR3 • official robot master')
 if root:root.select_set(True);bpy.context.view_layer.objects.active=root
 for mat in bpy.data.materials:
  if mat.use_nodes:
   bsdf=mat.node_tree.nodes.get('Principled BSDF')
   if bsdf:mat.diffuse_color=bsdf.inputs['Base Color'].default_value
 for screen in bpy.data.screens:
  for ar in screen.areas:
   if ar.type=='VIEW_3D':
    sp=ar.spaces.active;sp.shading.type='SOLID';sp.shading.color_type='MATERIAL';sp.shading.show_cavity=True;sp.overlay.show_extras=False;sp.overlay.show_floor=False
 scene['dimension_basis']='FR3 official visual meshes at exact source scale; surrounding architecture and props are explicitly dimensioned illustrative estimates, not surveyed CAD.'
 scene['metric_layout_version']='2026-10-17 physical proportions revision'
