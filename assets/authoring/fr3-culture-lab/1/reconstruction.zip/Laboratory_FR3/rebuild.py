"""Cross-platform launcher for the procedural laboratory scene (no extra packages)."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--blender', help='Path to Blender executable; default: find in PATH')
    parser.add_argument('--samples', type=int, default=64)
    parser.add_argument('--resolution', type=int, default=100, help='Percentage, 10 to 100')
    parser.add_argument('--build-only', action='store_true', help='Save .blend without rendering')
    args = parser.parse_args()
    blender = args.blender or shutil.which('blender')
    if not blender:
        parser.error('Blender not found. Supply --blender with the path to blender.exe.')
    if args.samples < 1 or not 10 <= args.resolution <= 100:
        parser.error('samples must be positive; resolution must be between 10 and 100')
    root = Path(__file__).resolve().parent
    env = os.environ.copy()
    env.update(SAMPLES=str(args.samples), RESOLUTION=str(args.resolution),
               BUILD_ONLY='1' if args.build_only else '0')
    subprocess.run([blender, '--background', '--factory-startup', '--python',
                    str(root / 'build_scene.py')], cwd=root, env=env, check=True)


if __name__ == '__main__':
    main()
