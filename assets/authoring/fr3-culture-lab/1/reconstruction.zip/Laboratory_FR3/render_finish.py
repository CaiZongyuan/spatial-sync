"""Create two lighting scenes sharing editable geometry, save, and optionally render."""
import bpy,os,json
from mathutils import Vector

def finish(scene,root):
 scene.name='01 • Daylight laboratory'
 c=scene.camera;c.location=(1.7,-4.6,2.6);c.rotation_euler=(Vector((-.35,.9,1.55))-c.location).to_track_quat('-Z','Y').to_euler();c.data.lens=48;c.data.dof.aperture_fstop=9;c.data.dof.focus_distance=(c.location-Vector((0,.7,1.65))).length
 for o in scene.objects:
  if o.type=='LIGHT':
   if o.name.startswith('DAY late'):o.data.energy=4
   if o.name.startswith('DAY broad'):o.data.energy=180
 m=bpy.data.materials.get('Subtle airborne dust volume')
 if m:m.node_tree.nodes.get('Principled Volume').inputs['Density'].default_value=.002
 scene.world.node_tree.nodes.get('Background').inputs[1].default_value=.14
 scene.cycles.samples=int(os.environ.get('SAMPLES','128'));scene.cycles.use_denoising=False;scene.render.resolution_percentage=int(os.environ.get('RESOLUTION','100'))
 from art_direction import apply
 apply(scene)
 from hero_polish import polish_heroes
 polish_heroes()
 if not bpy.data.objects.get('Metric overview camera'):
  cd=bpy.data.cameras.new('Metric overview lens');overview=bpy.data.objects.new('Metric overview camera',cd);scene.collection.objects.link(overview);overview.location=(3.8,-4.5,3.6);overview.rotation_euler=(Vector((0,.7,1.2))-overview.location).to_track_quat('-Z','Y').to_euler();cd.lens=43
 night=bpy.data.scenes.new('02 • Night laboratory')
 def clone_col(old,new):
  for o in old.objects:
   if o.type=='LIGHT':
    n=o.copy();n.data=o.data.copy();new.objects.link(n)
    if n.name.startswith('DAY'):n.hide_render=True
    elif n.name.startswith('NIGHT'):n.hide_render=False
    else:n.hide_render=False
   elif o.name=='Warm exterior sky backing':
    n=o.copy();n.data=o.data.copy();new.objects.link(n);m=o.data.materials[0].copy();m.node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value=0;n.data.materials.clear();n.data.materials.append(m)
   else:new.objects.link(o)
  for old_child in old.children:
   nc=bpy.data.collections.new(old_child.name+' • Night');new.children.link(nc);clone_col(old_child,nc)
 clone_col(scene.collection,night.collection)
 night.camera=c;night.world=scene.world.copy();night.world.name='Night cool ambient';night.world.node_tree.nodes.get('Background').inputs[1].default_value=.025
 night.unit_settings.system='METRIC';night.render.engine='CYCLES';night.cycles.samples=scene.cycles.samples;night.cycles.use_denoising=False;night.cycles.max_bounces=12;night.cycles.transmission_bounces=10;night.cycles.use_adaptive_sampling=True;night.cycles.adaptive_threshold=.03;night.cycles.adaptive_min_samples=32
 night.render.resolution_x=scene.render.resolution_x;night.render.resolution_y=scene.render.resolution_y;night.render.resolution_percentage=scene.render.resolution_percentage;night.render.image_settings.file_format='PNG';night.view_settings.view_transform='AgX'
 night['lighting_provenance']='Procedural area lights, no measured IES data; practical fixtures and warm cabinet illumination.'
 scene['build_instructions']='Run build_scene.py in Blender 4.3+. Environment SAMPLES=128 RESOLUTION=100 BUILD_ONLY=1(optional).'
 # Open file in an immediately useful rendered-camera composition, with tidy controls.
 for screen in bpy.data.screens:
  for ar in screen.areas:
   if ar.type=='VIEW_3D':
    ar.spaces.active.region_3d.view_perspective='CAMERA';ar.spaces.active.clip_end=200
 bpy.context.window.scene=scene
 for ob in scene.objects:ob.select_set(False)
 robot=bpy.data.objects.get('FR3 • official robot master')
 if robot:robot.select_set(True);bpy.context.view_layer.objects.active=robot
 bpy.ops.wm.save_as_mainfile(filepath=os.path.join(root,'laboratory_final.blend'),compress=True)
 report={'objects':len(scene.objects),'mesh_objects':sum(o.type=='MESH' for o in scene.objects),'materials':len(bpy.data.materials),'scenes':[scene.name,night.name],'units':'meters','room_bounds':{'x':[-2.2,2.2],'y':[-1.4,3.0],'z':[0,2.9]},'renders':['daylight_final.png','nighttime_final.png'],'external_images':[i.filepath for i in bpy.data.images if i.source=='FILE'],'procedural_only':False,'robot_source':'https://github.com/frankarobotics/franka_description','robot_model':'Franka Research 3 (FR3)' }
 with open(os.path.join(root,'scene_validation.json'),'w') as f:json.dump(report,f,indent=2)
 if os.environ.get('BUILD_ONLY')!='1':
  scene.render.filepath=os.path.join(root,'daylight_final.png');bpy.ops.render.render(write_still=True,scene=scene.name)
  if os.environ.get('RENDER_NIGHT','1')=='1':
   night.render.filepath=os.path.join(root,'nighttime_final.png');bpy.ops.render.render(write_still=True,scene=night.name)
 return report
