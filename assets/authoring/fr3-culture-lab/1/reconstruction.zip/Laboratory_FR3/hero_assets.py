"""Editable hero assets. Blender 4.3. Coordinates in metres, +Z up, front -Y.
Public API: build(ctx=None), build_robot(location), build_centrifuge(location).
Joints are nested empty controls; transform a Jxx control to articulate its children.
"""
import bpy, math
from mathutils import Vector
from math import sin,cos,pi

COL=None

def material(name,color,metal=0,rough=.35,trans=0):
    m=bpy.data.materials.get('Hero • '+name)
    if m:return m
    m=bpy.data.materials.new('Hero • '+name);m.diffuse_color=(*color,1);m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
    p.inputs['Transmission Weight'].default_value=trans;p.inputs['IOR'].default_value=1.46
    return m

def setup():
    global COL,M
    COL=bpy.data.collections.get('HERO')
    if not COL:COL=bpy.data.collections.new('HERO');bpy.context.scene.collection.children.link(COL)
    M={'white':material('warm ceramic polymer',(.73,.74,.70),.08,.28),'dark':material('graphite elastomer',(.025,.032,.037),.1,.38),'steel':material('satin stainless',(.48,.53,.55),.8,.22),'black':material('rotor anodized aluminium',(.018,.025,.029),.65,.28),'blue':material('royal blue polypropylene',(.035,.14,.38),0,.32),'glass':material('clear tube polypropylene',(.92,.97,1),0,.1,.92),'pink':material('pink culture medium',(.72,.055,.19),0,.16,.45),'ink':material('printed charcoal',(.055,.065,.07),0,.6),'screen':material('LCD blue green',(.055,.13,.13),.2,.22),'digits':material('LCD pale digits',(.47,.7,.64),0,.45),'red':material('stop red',(.48,.05,.025),0,.3),'yellow':material('warning yellow',(.85,.57,.035),0,.5)}

def objfinish(o,name,mat=None,parent=None):
    o.name=name
    for c in list(o.users_collection):c.objects.unlink(o)
    COL.objects.link(o)
    if mat:o.data.materials.append(mat)
    if parent:
        bpy.context.view_layer.update();matw=o.matrix_world.copy();o.parent=parent;o.matrix_world=matw
    return o

def empty(name,loc,parent=None):
    o=bpy.data.objects.new(name,None);COL.objects.link(o);o.location=loc;o.empty_display_type='PLAIN_AXES';o.empty_display_size=.08
    if parent:
        bpy.context.view_layer.update();w=o.matrix_world.copy();o.parent=parent;o.matrix_world=w
    return o

def box(name,loc,dims,mat,bevel=.012,parent=None):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=dims;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    if bevel:
        mod=o.modifiers.new('Machined edge radii','BEVEL');mod.width=bevel;mod.segments=3
        o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
    return objfinish(o,name,mat,parent)

def cyl(name,loc,radius,depth,mat,parent=None,axis=(0,0,1),verts=64):
    bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=radius,depth=depth,location=loc);o=bpy.context.object;o.rotation_mode='QUATERNION';o.rotation_quaternion=Vector((0,0,1)).rotation_difference(Vector(axis).normalized())
    be=o.modifiers.new('Soft machined rim','BEVEL');be.width=min(.006,depth/6);be.segments=3
    for p in o.data.polygons:p.use_smooth=True
    o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
    return objfinish(o,name,mat,parent)

def sphere(name,loc,scale,mat,parent=None):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=16,location=loc);o=bpy.context.object;o.scale=scale
    for p in o.data.polygons:p.use_smooth=True
    return objfinish(o,name,mat,parent)

def torus(name,loc,major,minor,mat,parent=None):
    bpy.ops.mesh.primitive_torus_add(major_segments=80,minor_segments=12,location=loc,major_radius=major,minor_radius=minor);o=bpy.context.object
    for p in o.data.polygons:p.use_smooth=True
    return objfinish(o,name,mat,parent)

def label(name,body,loc,size,mat,parent=None,rotation=(pi/2,0,0)):
    cu=bpy.data.curves.new(name,'FONT');cu.body=body;cu.size=size;cu.extrude=.00015;cu.align_x='CENTER';o=bpy.data.objects.new(name,cu);COL.objects.link(o);o.location=loc;o.rotation_euler=rotation;o.data.materials.append(mat)
    if parent:bpy.context.view_layer.update();w=o.matrix_world.copy();o.parent=parent;o.matrix_world=w
    return o

def shell_link(name,a,b,r1,r2,parent):
    a,b=Vector(a),Vector(b);v=b-a;L=v.length
    profile=[(0,r1*.64),(.025,r1*.9),(.055,r1),(.16,r1),(.81,r2),(.95,r2*.94),(1,r2*.68)]
    vs=[];fs=[];n=48
    for t,r in profile:
        for i in range(n):vs.append((r*cos(2*pi*i/n),r*sin(2*pi*i/n),t*L))
    for j in range(len(profile)-1):
        for i in range(n):fs.append((j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i))
    fs.extend([tuple(range(n-1,-1,-1)),tuple((len(profile)-1)*n+i for i in range(n))])
    me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();o=bpy.data.objects.new(name,me);COL.objects.link(o);o.location=a;o.rotation_mode='QUATERNION';o.rotation_quaternion=Vector((0,0,1)).rotation_difference(v.normalized());o.data.materials.append(M['white'])
    for p in me.polygons:p.use_smooth=True
    bpy.context.view_layer.update();w=o.matrix_world.copy();o.parent=parent;o.matrix_world=w
    return o

def build_robot(location=(-.5,.7,.95)):
    setup();base=Vector(location);P=lambda p:base+Vector(p)
    root=empty('ROBOT • master',base);root['description']='Seven-axis articulated collaborative laboratory arm; joint origins are editable.'
    box('Robot aluminium mounting foot',P((0,0,.035)),(.34,.29,.07),M['steel'],.012,root)
    box('Robot white pedestal flange',P((0,0,.08)),(.29,.25,.045),M['white'],.012,root)
    for x in [-.135,.135]:
        for y in [-.11,.11]:cyl('Base flange hex bolt',P((x,y,.078)),.012,.012,M['steel'],root,verts=6)
    points=[(0,0,.14),(0,0,.39),(.32,0,1.02),(.64,0,1.40),(1.02,0,1.25),(1.16,0,1.17),(1.22,-.005,1.08)]
    controls=[];prev=root
    for i,p in enumerate(points):
        control=empty('J%02d • robot axis'%(i+1),P(p),prev);control['axis_number']=i+1;controls.append(control);prev=control
        r=[.115,.14,.115,.125,.105,.083,.068][i]
        axis=(0,0,1) if i in [0,6] else (0,1,0)
        cyl('J%02d dark joint gasket'%(i+1),P(p),r*.97,.205 if i<5 else .13,M['dark'],control,axis)
        cyl('J%02d white actuator housing'%(i+1),P(p),r,.185 if i<5 else .115,M['white'],control,axis)
        if axis==(0,1,0):
            face=P((p[0],p[1]-.098,p[2]));cyl('J%02d circular faceplate'%(i+1),face,r*.84,.012,M['white'],control,axis)
            for ang in [pi/6,5*pi/6,3*pi/2]:
                q=face+Vector((r*.67*cos(ang),-.01,r*.67*sin(ang)));cyl('Joint recessed fastener',q,.009,.008,M['steel'],control,axis,verts=6)
        if i<len(points)-1:shell_link('L%02d sculpted link'%(i+1),P(p),P(points[i+1]),r*.87,[.10,.10,.095,.085,.07,.055][i],control)
    label('Robot arm wordmark','FRANKA ROBOTICS',P((.19,-.103,.74)),.027,M['ink'],controls[1],(pi/2,0,-.88))
    # Distinctive black triangular emblem on outer elbow plate.
    for dx,dz in [(-.02,.025),(.025,.025),(0,-.025)]:
        o=cyl('Robot triangular emblem',P((.64+dx,-.108,1.40+dz)),.022,.002,M['ink'],controls[3],(0,1,0),verts=3)
    end=controls[-1]
    P=lambda p:base+Vector(p)+Vector((0,0,.18))
    cyl('Tool changer brushed steel',P((1.22,-.005,.81)),.065,.095,M['steel'],end)
    for z in [.78,.82,.85]:torus('Tool changer locking collar',P((1.22,-.005,z)),.065,.004,M['dark'],end)
    box('Parallel gripper white body',P((1.22,-.005,.724)),(.16,.12,.10),M['white'],.018,end)
    for x in [1.162,1.278]:
        box('Gripper dark sliding jaw',P((x,-.005,.655)),(.027,.065,.07),M['dark'],.004,end)
        box('Gripper soft tube pad',P((x+(.014 if x<1.22 else -.014),-.005,.638)),(.014,.043,.044),M['dark'],.003,end)
    # Open-ended transparent conical centrifuge tube with medium and graduation print.
    tube=empty('Held 15 mL conical tube',P((1.22,-.005,.56)),end)
    cyl('Tube clear cylindrical wall',P((1.22,-.005,.557)),.024,.145,M['glass'],tube)
    bpy.ops.mesh.primitive_cone_add(vertices=48,radius1=.003,radius2=.024,depth=.055,location=P((1.22,-.005,.457)));objfinish(bpy.context.object,'Tube transparent conical tip',M['glass'],tube)
    cyl('Tube pink culture medium',P((1.22,-.005,.526)),.021,.086,M['pink'],tube)
    bpy.ops.mesh.primitive_cone_add(vertices=48,radius1=.002,radius2=.021,depth=.05,location=P((1.22,-.005,.46)));objfinish(bpy.context.object,'Pink medium conical meniscus',M['pink'],tube)
    cyl('Tube blue screw cap',P((1.22,-.005,.64)),.029,.026,M['blue'],tube)
    for i in range(24):
        a=i*2*pi/24;box('Cap grip rib',P((1.22+.029*cos(a),-.005+.029*sin(a),.64)),(.003,.003,.023),M['blue'],.0007,tube)
    for i in range(7):
        z=.491+i*.017;box('Tube graduated ink tick',P((1.217,-.029,z)),(.018 if i%2==0 else .011,.001,.0018),M['ink'],.0001,tube)
    label('Tube specimen mark','15\n10\n5',P((1.236,-.030,.501)),.010,M['ink'],tube)
    return root

def build_centrifuge(location=(1.3,.7,.95)):
    setup();B=Vector(location);P=lambda p:B+Vector(p);root=empty('CENTRIFUGE • master',B)
    # Contoured shell with a sloping front shoulder instead of a generic cube.
    verts=[(-.43,-.35,.055),(.43,-.35,.055),(.43,.35,.055),(-.43,.35,.055),(-.43,-.35,.30),(.43,-.35,.30),(.43,-.19,.49),(-.43,-.19,.49),(.43,.35,.49),(-.43,.35,.49)]
    faces=[(0,3,2,1),(0,1,5,4),(4,5,6,7),(7,6,8,9),(3,9,8,2),(0,4,7,9,3),(1,2,8,6,5)]
    me=bpy.data.meshes.new('Centrifuge formed housing');me.from_pydata([P(v) for v in verts],[],faces);me.update();o=bpy.data.objects.new('Centrifuge enamel outer housing',me);COL.objects.link(o);o.data.materials.append(M['white']);mod=o.modifiers.new('Cast housing corner radii','BEVEL');mod.width=.035;mod.segments=5;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');bpy.context.view_layer.update();w=o.matrix_world.copy();o.parent=root;o.matrix_world=w
    box('Centrifuge dark lower plinth',P((0,0,.055)),(.80,.65,.06),M['dark'],.025,root)
    for x in [-.32,.32]:
        for y in [-.25,.25]:cyl('Centrifuge rubber foot',P((x,y,.025)),.04,.05,M['dark'],root)
    # Visible chamber: deep black well + separate metallic sealing lips and rotor.
    cyl('Rotor chamber shadow',P((0,.065,.493)),.307,.012,M['black'],root)
    torus('Chamber stainless rim',P((0,.065,.503)),.308,.011,M['steel'],root)
    torus('Chamber rubber gasket',P((0,.065,.503)),.292,.009,M['dark'],root)
    cyl('Fixed-angle rotor platter',P((0,.065,.508)),.236,.019,M['black'],root)
    cyl('Rotor central spindle',P((0,.065,.532)),.045,.055,M['steel'],root)
    cyl('Rotor knurled locking hub',P((0,.065,.565)),.035,.026,M['dark'],root)
    for i in range(12):
        a=i*2*pi/12;x=.194*cos(a);y=.065+.194*sin(a)
        cyl('Rotor empty tube socket',P((x,y,.523)),.030,.013,M['dark'],root)
        torus('Rotor socket machined rim',P((x,y,.528)),.027,.003,M['steel'],root)
        if i%3!=0:
            cyl('Rotor inserted tube neck',P((x,y,.54)),.021,.027,M['glass'],root)
            cyl('Rotor blue sample cap',P((x,y,.562)),.026,.021,M['blue'],root)
    # Lid geometry in a closed local frame, pivoted backward 104 degrees at its hinge.
    hinge=empty('LID • hinge control (rotate X)',P((0,.34,.49)),root)
    lidparts=[]
    def lidbox(n,l,d,m,b=.01):
        o=box(n,P(l),d,m,b,hinge);lidparts.append(o);return o
    lidbox('Lid rounded enamel shell',(0,.035,.525),(.82,.65,.055),M['white'],.035)
    lidbox('Lid underside dark insert',(0,.035,.491),(.75,.59,.014),M['dark'],.028)
    o=cyl('Lid inner circular brushed plate',P((0,.055,.480)),.272,.018,M['steel'],hinge);lidparts.append(o)
    o=torus('Lid circular vacuum seal',P((0,.055,.468)),.275,.012,M['dark'],hinge);lidparts.append(o)
    o=cyl('Lid central latch receiver',P((0,.055,.468)),.034,.015,M['dark'],hinge);lidparts.append(o)
    for x in [-.34,.34]:
        for y in [-.21,.28]:
            o=cyl('Lid recessed screw',P((x,y,.477)),.010,.005,M['steel'],hinge,verts=6);lidparts.append(o)
    # Parent transforms inverse frozen before local hinge rotation.
    bpy.context.view_layer.update();hinge.rotation_euler.x=math.radians(-104)
    for x in [-.29,.29]:cyl('Rear hinge barrel',P((x,.342,.494)),.025,.10,M['steel'],root,(1,0,0))
    # Control panel follows sloped shoulder; all elements are individually editable.
    panel=empty('CONTROL PANEL • sloped plane',P((-.11,-.282,.401)),root);panel.rotation_euler.x=math.radians(50)
    def panelpart(o,local):o.parent=panel;o.location=local;o.rotation_euler=(0,0,0);return o
    panelpart(box('Control fascia',(0,0,0),(.43,.175,.008),M['dark'],.012), (0,0,0))
    panelpart(box('LCD inset display',(0,0,0),(.23,.089,.004),M['screen'],.006),(-.073,.01,.007))
    for text,loc,size in [('4500',(-.079,.008,.010),.035),('RPM     06:00',(-.075,-.026,.010),.014),('CENTRIFUGE  5810 R',(0,-.071,.009),.010)]:
        o=label('Panel '+text,text,(0,0,0),size,M['digits'],rotation=(0,0,0));panelpart(o,loc)
    for x in [.087,.136,.185]:
        for y in [-.036,.012,.058]:panelpart(cyl('Control keypad button',(0,0,0),.014,.005,M['white'],verts=32),(x,y,.009))
    panelpart(cyl('Stop button',(0,0,0),.014,.006,M['red'],verts=32),(.185,-.036,.013))
    label('Centrifuge front badge','LABSPIN',P((-.05,-.353,.182)),.028,M['ink'],root)
    label('Centrifuge model inscription','REFRIGERATED  •  5810 R',P((-.05,-.353,.146)),.012,M['ink'],root)
    for i in range(12):box('Side ventilation slot',P((.432,-.03+i*.022,.17)),(.002,.010,.08),M['dark'],.003,root)
    # Yellow safety triangle on front-right shoulder.
    warn=cyl('Caution decal triangle',P((.333,-.277,.405)),.025,.001,M['yellow'],root,(0,-.76,.65),verts=3)
    label('Caution symbol','!',P((.333,-.282,.411)),.022,M['ink'],root,(math.radians(50),0,0))
    return root

def build(ctx=None):
    return {'robot':build_robot(),'centrifuge':build_centrifuge()}

if __name__=='__main__':
    build();print('HERO_ASSET_SMOKE_OK',len(bpy.data.collections['HERO'].objects))
