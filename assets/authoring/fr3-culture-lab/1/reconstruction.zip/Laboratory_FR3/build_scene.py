import bpy, math, os, sys, random, json
from mathutils import Vector
ROOT=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,ROOT)
random.seed(23)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
 if c.name!='Collection' and c.users==0: bpy.data.collections.remove(c)
scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1

def material(name,color,metal=0,rough=.4,trans=0,emission=0):
 m=bpy.data.materials.new(name);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 p.inputs['Transmission Weight'].default_value=trans;p.inputs['IOR'].default_value=1.46
 if emission:p.inputs['Emission Color'].default_value=(*color,1);p.inputs['Emission Strength'].default_value=emission
 return m
mats={
'white':material('Warm porcelain enamel',(.72,.74,.71),.15,.29),
'wall':material('Warm mineral painted plaster',(.61,.62,.57),0,.83),
'steel':material('Brushed stainless steel',(.45,.49,.49),.8,.28),
'dark':material('Charcoal rubber',(.025,.032,.034),.05,.46),
'blue':material('Polypropylene laboratory blue',(.022,.095,.23),0,.33),
'glass':material('Borosilicate glass IOR 1.46',(.91,.97,1),0,.07,1),
'red':material('Culture medium phenol red',(.61,.025,.075),0,.14,.5),
'orange':material('Sterile cap orange',(.82,.14,.018),0,.3),
'paper':material('Archival offwhite paper',(.81,.8,.7),0,.9),
'light':material('Warm fluorescent phosphor', (1,.8,.45),0,.3,0,4),
'green':material('Plant leaf',(.09,.19,.025),0,.56),
}
# Subtle procedural roughness and microtexture, avoiding heavy image textures.
for key in ['steel','white','wall']:
 m=mats[key];n=m.node_tree.nodes;p=n.get('Principled BSDF');tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=95 if key=='steel' else 180;tex.inputs['Detail'].default_value=2
 bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.13 if key=='wall' else .07;bump.inputs['Distance'].default_value=.002
 m.node_tree.links.new(tex.outputs['Fac'],bump.inputs['Height']);m.node_tree.links.new(bump.outputs['Normal'],p.inputs['Normal'])

def finish(o,name,mat,bevel=0):
 o.name=name
 if mat:o.data.materials.append(mat)
 if bevel:
  mod=o.modifiers.new('Manufactured edge radii','BEVEL');mod.width=bevel;mod.segments=3
  mod=o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
 return o
def box(name,loc,dims,mat,bevel=.01):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.dimensions=dims;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,mat,bevel)
def cyl(name,loc,radius,depth,mat,vertices=48):
 bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=loc);o=finish(bpy.context.object,name,mat,.003)
 for p in o.data.polygons:p.use_smooth=True
 return o
def sphere(name,loc,scale,mat):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=16,location=loc);o=bpy.context.object;o.scale=scale
 for p in o.data.polygons:p.use_smooth=True
 return finish(o,name,mat)
def rod(name,a,b,radius,mat):
 d=Vector(b)-Vector(a);o=cyl(name,(Vector(a)+Vector(b))/2,radius,d.length,mat);o.rotation_euler=d.to_track_quat('Z','Y').to_euler();return o
def text(name,body,loc,size,mat,rotation=(0,0,0)):
 cu=bpy.data.curves.new(name,'FONT');cu.body=body;cu.size=size;cu.extrude=.00025;o=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=rotation;o.data.materials.append(mat);return o
ctx=dict(box=box,cyl=cyl,sphere=sphere,rod=rod,text=text,mats=mats,props_config={'plant_pos':(1.97,1.1,2.6675)})

def area(name,loc,power,color,size,target):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.color=color;d.shape='DISK';d.size=size;o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();return o
# Architectural shell, dimensioned around the unscaled official FR3.
box('Continuous laboratory resin floor',(0,.8,-.09),(4.4,4.4,.18),material('Epoxy floor',(.27,.3,.29),.06,.46))
box('Back wall below glazing',(0,3.05,.55),(4.4,.18,1.1),mats['wall'])
box('Back wall above glazing',(0,3.05,2.78),(4.4,.18,.24),mats['wall'])
box('Left plaster wall',(-2.2,.8,1.45),(.18,4.4,2.9),mats['wall'])
for x in [-2.1,2.1]:box('Glazing pier',(x,3,1.88),(.2,.2,1.6),mats['wall'])
for x in [-1.95,-.65,.65,1.95]:box('Window vertical mullion',(x,2.97,1.88),(.055,.10,1.55),mats['white'])
for z in [1.1,2.65]:box('Window sill and header',(0,2.92,z),(4.0,.23,.06),mats['white'])
for bank,x in enumerate([-1.3,0,1.3]):
 for j in range(23):
  slat=box('Venetian blind %d slat %02d'%(bank,j),(x,2.88,1.14+j*.068),(1.24,.065,.014),mats['white'],.002);slat.rotation_euler.x=math.radians(-18)
 for xx in [x-.42,x+.42]:rod('Blind suspension cord',(xx,2.825,1.12),(xx,2.825,2.64),.003,mats['paper'])
 box('Blind headrail',(x,2.87,2.67),(1.27,.1,.055),mats['white'])
box('Continuous ceiling',(0,.8,2.98),(4.4,4.4,.12),mats['wall'])
# Outdoor buildings: subdued visible geometry provides urban depth.
for i,(x,w,h) in enumerate([(-4,1.2,3.7),(-1.6,1.3,2.8),(.7,1.0,4.3),(3,1.5,3.2),(5,1,4.5)]):
 o=box('Distant city building %d'%i,(x,11,h/2),(w,1,h),material('Distant facade %d'%i,(.38+i*.02,.43+i*.02,.45+i*.02),0,.85))
 for z in [j*.3+.3 for j in range(int(h/.3))]:box('Distant facade horizontal line',(x,10.48,z),(w,.015,.025),mats['steel'],0)
# Furniture, surfaces all explicitly defined.
def bench(name,xc,yc,w,d,z):
 box(name+' stainless worksurface',(xc,yc,z-.025),(w,d,.05),mats['steel'],.015)
 for x in [xc-w/2+.08,xc+w/2-.08]:
  for y in [yc-d/2+.08,yc+d/2-.08]:box(name+' square leg',(x,y,(z-.05)/2),(.055,.055,z-.05),mats['steel'],.004)
 box(name+' front apron',(xc,yc-d/2+.06,z-.12),(w-.12,.045,.13),mats['white'])
 box(name+' underbench shelf',(xc,yc,.2),(w-.15,d-.12,.035),mats['steel'])
bench('Foreground culture preparation bench',0,-.75,2.8,.85,.9)
bench('Robotic cell processing bench',.5,.65,2,.8,.95)
bench('Rear cleaning counter',0,2.6,3.8,.55,.9)
# Biosafety cabinet: 1.4m overall width, 0.84m depth, 2.2m top / 0.9m worktop.
x=-1.35
box('BSC rear metal lining',(x,1.18,1.42),(1.25,.045,1.04),mats['steel'])
box('BSC sterile work tray',(x,.8,.875),(1.35,.8,.05),mats['steel'])
for xx in [-2.025,-.675]:
 box('BSC vertical side post',(xx,.42,1.51),(.05,.075,1.28),mats['blue'])
 box('BSC side panel',(xx,.81,1.45),(.045,.8,1.1),mats['white'])
box('BSC upper filter plenum',(x,.8,2.06),(1.4,.84,.28),mats['white'],.025)
box('BSC angled control fascia',(x,.36,1.88),(1.4,.08,.14),mats['white'])
box('BSC control panel',(-.95,.31,1.88),(.23,.014,.08),mats['dark'],.005)
for j in range(4):box('BSC membrane key',(-1.02+j*.03,.30,1.87),(.018,.006,.018),mats['blue'],.003)
text('BSC brand label','CELL CULTURE',(-1.94,.365,2.07),.063,mats['blue'],(math.pi/2,0,0))
text('BSC specification','CLASS II  /  CLEAN AIR',(-1.52,.31,1.9),.018,mats['dark'],(math.pi/2,0,0))
box('BSC sash glass',(x,.41,1.75),(1.26,.008,.15),mats['glass'],.001)
box('BSC fluorescent work light',(x,.65,1.80),(1.15,.07,.03),mats['light'])
for xx in [-1.95,-.75]:box('BSC stand leg',(xx,.95,.44),(.055,.06,.88),mats['steel'])
for i in range(53):box('BSC front intake slot',(-1.94+i*.022,.46,.904),(.009,.10,.003),mats['dark'],.002)
area('BSC warm task light',(-1.35,.65,1.77),45,(1,.69,.32),.9,(-1.35,.85,.9))
# Storage racks behind sterile cabinet and on right edge.
def rack(name,x,y,w,d,h):
 for xx in [x-w/2,x+w/2]:
  for yy in [y-d/2,y+d/2]:box(name+' uprights',(xx,yy,h/2),(.035,.035,h),mats['steel'],.003)
 for z in [.22,.88,1.55,2.2,2.65]:
  box(name+' shelf',(x,y,z),(w,d,.035),mats['steel'])
  for i in range(3):
   bx=x-w*.32+i*w*.32
   if z<2.3:
    box(name+' archive carton',(bx,y+.03,z+.17),(w*.27,d*.73,.31),mats['paper'])
    box(name+' inventory label',(bx,y-d*.37-.001,z+.17),(.16,.002,.09),mats['white'],.001)
    text(name+' inventory code','STERILE\nLOT 24.08',(bx-.065,y-d*.37-.004,z+.18),.017,mats['dark'],(math.pi/2,0,0))
rack('Left rear supply rack',-1.35,2.57,1.35,.5,2.8)
rack('Right supply shelving',1.97,1.0,.42,1.15,2.7)
# Chairs, ergonomic recognizable soft forms from procedural geometry.
def chair(name,x,y,rot):
 root=bpy.data.objects.new(name,None);scene.collection.objects.link(root);root.location=(x,y,0);root.rotation_euler.z=rot
 def own(o):o.parent=root;return o
 own(cyl(name+' pneumatic piston',(0,0,.32),.045,.48,mats['steel']))
 own(box(name+' upholstered seat',(0,0,.55),(.50,.45,.12),mats['dark'],.065))
 own(box(name+' lumbar back',(0,-.20,.88),(.50,.10,.49),mats['dark'],.065))
 for a in range(5):
  ang=a*2*math.pi/5;end=(math.cos(ang)*.28,math.sin(ang)*.28,.1);own(rod(name+' base spoke',(0,0,.15),end,.024,mats['dark']));own(sphere(name+' caster',end,(.047,.047,.04),mats['dark']))
chair('BSC operator chair',-1.35,-.05,.1)
chair('Foreground technician chair',1.55,-1.05,-.23)
# Ceiling practical lights for nighttime variant.
for x in [-1.0,1.0]:
 box('Ceiling luminaire housing',(x,1.2,2.86),(1.1,.28,.04),mats['white']);box('Ceiling luminous diffuser',(x,1.2,2.83),(1,.22,.015),mats['light'])
 o=area('NIGHT ceiling light',(x,1.2,2.8),280,(.65,.77,1),1.0,(x,1.3,0));o.hide_render=True
# Asset integrations.
for module in ['hero_assets','lab_props']:
 try:
  m=__import__(module);m.build(ctx);print('BUILT_MODULE',module)
 except ModuleNotFoundError:raise RuntimeError('Required asset module missing: '+module)
import import_fr3
import_fr3.replace_existing()
# Main photography camera.
bpy.ops.object.camera_add(location=(3.3,-8,3.1));camera=bpy.context.object;camera.name='Camera daylight reference composition';camera.rotation_euler=(Vector((-.45,1.2,1.65))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.lens=65;scene.camera=camera
camera.data.dof.use_dof=True;camera.data.dof.focus_distance=(camera.location-Vector((0,.7,1.75))).length;camera.data.dof.aperture_fstop=8
# Physically directional daylight, low density visible air.
sun_data=bpy.data.lights.new('DAY late afternoon sun','SUN');sun_data.energy=4;sun_data.angle=math.radians(3);sun_data.color=(1,.84,.63);sun=bpy.data.objects.new('DAY late afternoon sun',sun_data);scene.collection.objects.link(sun);sun.rotation_euler=Vector((-.55,-1,-.5)).to_track_quat('-Z','Y').to_euler()
area('DAY broad window sky',(0,2.8,2.5),180,(.7,.83,1),4,(0,.3,1.4))
area('DAY soft photographic bounce',(1,-3.5,3.5),130,(1,.88,.72),4,(-.4,1,1.2))
world=bpy.data.worlds.new('Laboratory environment');scene.world=world;world.use_nodes=True;world.node_tree.nodes.get('Background').inputs[0].default_value=(.4,.49,.62,1);world.node_tree.nodes.get('Background').inputs[1].default_value=.14
volume=bpy.data.materials.new('Subtle airborne dust volume');volume.use_nodes=True;ns=volume.node_tree.nodes;ns.clear();out=ns.new('ShaderNodeOutputMaterial');v=ns.new('ShaderNodeVolumePrincipled');v.inputs['Density'].default_value=.002;v.inputs['Anisotropy'].default_value=.35;volume.node_tree.links.new(v.outputs['Volume'],out.inputs['Volume']);box('Atmospheric interior volume',(0,.8,1.45),(4.2,4.2,2.8),volume,0)
scene.render.engine='CYCLES';scene.cycles.samples=int(os.environ.get('SAMPLES','64'));scene.cycles.use_denoising=False;scene.cycles.max_bounces=8;scene.cycles.transmission_bounces=6
scene.render.resolution_x=1456;scene.render.resolution_y=1088;scene.render.resolution_percentage=int(os.environ.get('RESOLUTION','65'))
scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX'
scene.render.film_transparent=False
scene['reference']='User-supplied laboratory photograph; estimated spatial reconstruction, not measured CAD.'
scene['asset_provenance']='Official Franka Research 3 visual meshes from frankarobotics/franka_description, with procedural architecture, centrifuge and laboratory props. No external AI mesh generation or measured IES profiles used.'
scene['day_night_usage']='Set DAY lamps hide_render True; NIGHT lamps False; world strength .025 for night.'
# Sensible collection organization for editing.
for label,prefixes in [('Architecture',['Continuous','Back wall','Left plaster','Glazing','Window','Venetian','Blind','Distant']),('Furniture',['Foreground culture','Robotic cell','Rear cleaning','BSC','Left rear','Right supply','Foreground technician']),('Lighting',['DAY','NIGHT','Ceiling','Atmospheric'])]:
 col=bpy.data.collections.new(label);scene.collection.children.link(col)
 for ob in list(scene.objects):
  if any(ob.name.startswith(p) for p in prefixes) and ob.name not in col.objects:
   for old in list(ob.users_collection):old.objects.unlink(ob)
   col.objects.link(ob)
scene.name='01 • Daylight laboratory'
from render_finish import finish
print(finish(scene,ROOT))
